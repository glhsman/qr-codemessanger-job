-- Schema for QR Landing App

CREATE TABLE IF NOT EXISTS `settings` (
  `key` VARCHAR(191) NOT NULL,
  `value` TEXT NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `scans` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `ts` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip` VARCHAR(45) DEFAULT NULL,
  `user_agent` TEXT DEFAULT NULL,
  `referrer` TEXT DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `messages` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(255) NOT NULL,
  `content` TEXT NOT NULL,
  `active_from` DATETIME DEFAULT NULL,
  `active_until` DATETIME DEFAULT NULL,
  `daily_start` TIME DEFAULT NULL,
  `daily_end` TIME DEFAULT NULL,
  `active_days` VARCHAR(255) DEFAULT NULL,
  `is_default` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Legacy default text (kept for backward compatibility)
INSERT INTO `settings` (`key`, `value`)
VALUES ('landing_message', 'Hallo! Scanne erfolgreich. Passe diese Nachricht im Adminbereich an.')
ON DUPLICATE KEY UPDATE `value` = VALUES(`value`);

-- Ensure one default message exists for fresh installations
INSERT INTO `messages` (`title`, `content`, `is_default`)
SELECT
  'Standard-Meldung',
  COALESCE(
    (SELECT `value` FROM `settings` WHERE `key` = 'landing_message' LIMIT 1),
    'Hallo! Scanne erfolgreich. Passe diese Nachricht im Adminbereich an.'
  ),
  1
WHERE NOT EXISTS (
  SELECT 1 FROM `messages` WHERE `is_default` = 1
);
