<?php
require_once __DIR__ . '/../config.php';
session_start();
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params['path'], $params['domain'] ?? '', $params['secure'] ?? false, $params['httponly'] ?? false);
}
session_destroy();
header('Location: ' . BASE_URL . '/admin/login.php');
exit;
?>