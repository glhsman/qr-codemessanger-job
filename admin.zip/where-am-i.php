<?php
echo "Current File: " . __FILE__ . "\n";
echo "Document Root: " . $_SERVER['DOCUMENT_ROOT'] . "\n";
echo "Real Path: " . realpath(__FILE__) . "\n";
?>
